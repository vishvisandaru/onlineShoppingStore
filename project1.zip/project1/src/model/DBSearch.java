/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Dell
 */
public class DBSearch {
    
 Statement stmt;
 ResultSet rs;
public ResultSet searchLogin(String usName) {
 try {
 stmt = (Statement) DBconnection.connect();
 String name = usName;
//Execute the Query
rs = stmt.executeQuery("SELECT * FROM customer where Name='" + name + "'");
 } catch (Exception e) {
 }
 return rs;
 }
    
}
